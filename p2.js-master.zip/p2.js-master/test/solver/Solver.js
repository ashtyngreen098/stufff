var Solver = require(__dirname + '/../../src/solver/Solver');

exports.construct = function(test){
    var solver = new Solver();
    test.done();
};

exports.addEquation = function(test){
    // STUB
    test.done();
};

exports.addEquations = function(test){
    // STUB
    test.done();
};

exports.removeAllEquations = function(test){
    // STUB
    test.done();
};

exports.removeEquation = function(test){
    // STUB
    test.done();
};

exports.solve = function(test){
    // STUB
    test.done();
};

exports.sortEquations = function(test){
    // STUB
    test.done();
};

