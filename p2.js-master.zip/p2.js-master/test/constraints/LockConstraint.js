var LockConstraint = require(__dirname + '/../../src/constraints/LockConstraint');

exports.construct = function(test){
    // STUB
    test.done();
};

