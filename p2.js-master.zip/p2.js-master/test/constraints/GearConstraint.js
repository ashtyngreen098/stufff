var GearConstraint = require(__dirname + '/../../src/constraints/GearConstraint');

exports.construct = function(test){
    // STUB
    test.done();
};

