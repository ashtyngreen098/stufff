var PrismaticConstraint = require(__dirname + '/../../src/constraints/PrismaticConstraint');

exports.construct = function(test){
    // STUB
    test.done();
};

exports.disableMotor = function(test){
    // STUB
    test.done();
};

exports.enableMotor = function(test){
    // STUB
    test.done();
};

exports.update = function(test){
    // STUB
    test.done();
};

